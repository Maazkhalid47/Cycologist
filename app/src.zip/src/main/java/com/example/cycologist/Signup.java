package com.example.cycologist;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Signup extends AppCompatActivity {
    DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReferenceFromUrl("https://cycologist-default-rtdb.firebaseio.com/");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
     final EditText edtname = findViewById(R.id.edtname);
        final  EditText edtfname = findViewById(R.id.edtfname);
        final EditText edtage = findViewById(R.id.edtage);
        final EditText edtemail = findViewById(R.id.edtemailS);
        final EditText edtpswd = findViewById(R.id.edtpswdS);
       final Button signup = findViewById(R.id.btnsignup);
        final TextView logintxt = findViewById(R.id.logintxt);
        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final String name=edtname.getText().toString();
                final String fname=edtfname.getText().toString();
                final String age=edtage.getText().toString();
                final String email=edtemail.getText().toString();
                final String pswd=edtpswd.getText().toString();
                if(name.isEmpty()||fname.isEmpty()||age.isEmpty()||email.isEmpty()||pswd.isEmpty()){
                    Toast.makeText(Signup.this, "Fill All Fields!", Toast.LENGTH_SHORT).show();
                }
                else{
                    databaseReference.child("users").addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            if(snapshot.hasChild(email)){
                                Toast.makeText(Signup.this, "Email already regstered", Toast.LENGTH_SHORT).show();
                            }else{
                                //sending data to firebase
                                // using email as unique identifier
                                databaseReference.child("users").child(email).child("name").setValue(name);
                                databaseReference.child("users").child(email).child("father name").setValue(fname);
                                databaseReference.child("users").child(email).child("age").setValue(age);
                                databaseReference.child("users").child(email).child("password").setValue(pswd);
                                Toast.makeText(Signup.this, "Registered ", Toast.LENGTH_LONG).show();
                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }
                    });


                }
            }
        });
        logintxt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }

}